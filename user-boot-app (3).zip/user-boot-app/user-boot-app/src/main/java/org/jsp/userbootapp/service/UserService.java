package org.jsp.userbootapp.service;

import java.util.List;
import java.util.Optional;

import org.jsp.userbootapp.dao.UserDao;
import org.jsp.userbootapp.dto.ResponseStructure;
import org.jsp.userbootapp.dto.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
@Service
public class UserService {
	@Autowired
	private UserDao dao;
	
	public ResponseStructure<User> saveUser(@RequestBody User user)
	{
		ResponseStructure<User> structure=new ResponseStructure<>();
		structure.setBody(dao.saveUser(user));
		structure.setMessage("user saved successfully");
		structure.setCode(HttpStatus.ACCEPTED.value());
		return structure;
	}
	
	public ResponseStructure<User> updateUser(@RequestBody User user)
	{
		ResponseStructure<User> structure=new ResponseStructure<>();
		structure.setBody(dao.saveUser(user));
		structure.setMessage("user updated successfully");
		structure.setCode(HttpStatus.ACCEPTED.value());
		return structure;
	}
	
	public ResponseStructure<String> deleteUser(@PathVariable int id)
	{
		Optional<User> recUser=dao.findById(id);
		ResponseStructure<String> structure=new ResponseStructure<>();
		if(recUser.isPresent()) {
			dao.deletedById(id);
			structure.setMessage("user found and deleted");
			structure.setBody("User Found");
			structure.setCode(HttpStatus.FOUND.value());
		}
		else {
			structure.setBody("user not found");
			structure.setMessage("Unable to delete the user who is not present");
			structure.setCode(HttpStatus.NOT_FOUND.value());
		}
		return structure;
		
	}
	
	public ResponseStructure<User> findUserById(@PathVariable int id)
	{
		ResponseStructure<User> structure=new ResponseStructure<>();
		Optional<User> recUser=dao.findById(id);
		if(recUser.isPresent()) {
			structure.setMessage("user found");
			structure.setBody(recUser.get());
			structure.setCode(HttpStatus.FOUND.value());
		}
		else {
			structure.setBody(null);
			structure.setMessage("user not found");
			structure.setCode(HttpStatus.NOT_FOUND.value());
		}
		return structure;
	}
	
	public ResponseStructure<List<User>> findAllUsers()
	{
		ResponseStructure<List<User>> structure= new ResponseStructure<>();
		structure.setBody(dao.findAll());
		structure.setMessage("List of users");
		structure.setCode(HttpStatus.OK.value());
		return structure;
	}
	public ResponseStructure<User> verifyUser(@RequestParam long phone, @RequestParam String password)
	{
		User u=dao.verifyUser(phone, password);
		ResponseStructure<User> structure=new ResponseStructure<User>();
		if(u!=null) {
			structure.setMessage("user has been verified");
			structure.setBody(u);
			structure.setCode(HttpStatus.FOUND.value());
		}
		else {
			structure.setBody(null);
			structure.setMessage("Invalid phone number or password");
			structure.setCode(HttpStatus.NOT_FOUND.value());
		}
		return structure;
	}


}
